import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
id:any
  constructor(private service:ApiService,private router:ActivatedRoute) {
 

   }

  ngOnInit(): void {
  
   
    this.router.params.subscribe((res:any)=>{
      console.log(res)
this.id=res.id
    })

  }
    
  
  addData(data:any){
    console.log(data)
          
this.service.UpdateData(this.id,data).subscribe((result)=>{
  console.log(result)
  })
      }
 
}
