import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from './api.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'practice';
  data:any

  constructor(private service:ApiService,private router:Router){
 

  }
 
}


































// map: any;
// platform: any;
// circle: any;
// latitude: any;
// longitude: any;
// radius: number | undefined;
// APIKEY: string = 'AIzaSyD5mNYRGJ8jdKmW8SGeSw0Zn3YXPd3Jg7Q';

// constructor() {}
// ngOnInit(): void {
//   var that = this;  
//   setTimeout(function () {
//     that.platform = new H.service.Platform({
//       'apikey': that.APIKEY,
//     });
//     var defaultLayers = that.platform.createDefaultLayers();
//     that.map = new H.Map(
//       document.getElementById("mapcontainer"),
//       defaultLayers.raster.terrain.map,
//       {
//         zoom: 10,
//         center: {
//           lat: 52.5,
//           lng: 13.4,  
//         },
//       }
      
//     );
 
//   }, 2000);

// }

// AddCircle() {
//   if (this.circle) {
//     this.map.removeObject(this.circle);
//   }
//   this.circle = new H.map.Circle(
//     {
//       lat: this.latitude,
//       lng: this.longitude,
//     },
//     this.radius
//   );
//   this.map.setCenter({
//     lat: this.latitude,
//     lng: this.longitude,
//   });
//   this.map.addObject(this.circle);
// }

// RemoveCircle() {
//   if (this.circle) {
//     this.map.removeObject(this.circle);
//     this.circle = undefined;
//   }

