import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class ApiService {
url="https://node-server-livid.vercel.app/user"
  constructor(private http:HttpClient) { }

  getData(){
return this.http.get(this.url)
  }
  AddData(data:any){
    return this.http.post(this.url,data)
  }
  DeleteData(id:any){
    return this.http.delete(`${this.url}/${id}`)
  }
  UpdateData(id:any,data:any){
    return this.http.put(`${this.url}/${id}`,data)
  }
}
