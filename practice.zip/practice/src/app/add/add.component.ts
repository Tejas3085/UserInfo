import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  constructor(private service:ApiService) { }

  ngOnInit(): void {
  }
addData(data:any){
// console.log(data)
this.service.AddData(data).subscribe((res)=>{
  console.log(res)
})
}
}
