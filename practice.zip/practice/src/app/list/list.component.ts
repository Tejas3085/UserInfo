import { convertUpdateArguments } from '@angular/compiler/src/compiler_util/expression_converter';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
data:any=''
  constructor(private service:ApiService,private router:Router){}
  

  ngOnInit(): void {
  
  this.service.getData().subscribe((data)=>{
    console.log(data)
    this.data=data
    })

  }
  addData(){
this.router.navigate(['/add'])
  }
  deleteData(id:any){
    // console.log(id)
    this.service.DeleteData(id).subscribe((res)=>{
      console.log(res)         
    })
    
  }
  Update(id:any){
    this.router.navigate(['/update/',id])
  }
}

